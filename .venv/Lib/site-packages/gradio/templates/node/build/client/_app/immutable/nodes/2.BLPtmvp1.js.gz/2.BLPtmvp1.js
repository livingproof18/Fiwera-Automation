import{Y as e,_ as n}from"../chunks/2.BrEqyLn2.js";export{e as component,n as universal};
//# sourceMappingURL=2.BLPtmvp1.js.map
