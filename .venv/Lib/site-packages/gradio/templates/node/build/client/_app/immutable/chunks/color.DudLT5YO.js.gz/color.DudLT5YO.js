import{v as o}from"./2.BrEqyLn2.js";const t=r=>o[r%o.length];export{t as g};
//# sourceMappingURL=color.DudLT5YO.js.map
